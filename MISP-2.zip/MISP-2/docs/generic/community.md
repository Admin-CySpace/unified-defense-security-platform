!!! notice
    Maintained and tested by the community.<br />
    Parts of the installation procedures can also be found in the automatic VM generator script [bootstrap.sh](https://github.com/MISP/misp-packer/blob/18.04/scripts/bootstrap.sh) of misp-packer.
