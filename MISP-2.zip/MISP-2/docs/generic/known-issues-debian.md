# Known issues on Debian

## Debian 9.9 & 10

### misp-workers


#### Issue
Currently there is an [issue](https://github.com/MISP/MISP/issues/4047) with the misp-workers not being started on boot.

#### Workaround
Restart all workers in the Web UI.
