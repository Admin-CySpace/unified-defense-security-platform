!!! notice
    There are technically only minor differences between CentOS and RHEL.<br />
    For more information on what might differ, [this StackExchange](https://unix.stackexchange.com/questions/27323/is-centos-exactly-the-same-as-rhel) question might answer some questions.
