:warning: This folder has generic instructions that are platform specific and some are platform independant. NO full MISP Guides are to live here.
