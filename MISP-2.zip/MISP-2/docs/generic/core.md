!!! notice
    Maintained and tested by the MISP core team.<br />
    Enjoy installing MISP. For any issues see [here](https://github.com/MISP/MISP/issues)

