!!! warning 
    All guides prefixed with 'x' are not being actively maintained by the MISP core maintainers.<br />
    If you want to change that, please reach out on [gitter](https://gitter.im/MISP/MISP) and<br />
    let the community know which INSTALL guide you are maintaining.<br />
