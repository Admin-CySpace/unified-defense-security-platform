# License

The MISP INSTALL guides are dual-licensed under [GNU Affero General Public License version 3](http://www.gnu.org/licenses/agpl-3.0.html) and [CC-BY-SA 4.0 international](https://creativecommons.org/licenses/by-sa/4.0/).

* Copyright \(C\) 2014-2021 CIRCL - Computer Incident Response Center Luxembourg
