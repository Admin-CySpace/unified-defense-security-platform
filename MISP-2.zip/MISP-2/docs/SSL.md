# Let's encrypt SSL with stock MISP install

This will explain how to enable [letsencrypt]*(https://letsencrypt.org/) on a stock Ubuntu/Debian MISP install.
