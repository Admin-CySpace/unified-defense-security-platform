curl -H "Accept: application/xml" -H "Authorization: 3xoBdRRCjr3dLS0WyqETzWZrMhmpK5iNCGpQxgsR" \
-X GET http://localhost:8888/events/$1

#curl -H "Accept: application/json" -H "Authorization: 3xoBdRRCjr3dLS0WyqETzWZrMhmpK5iNCGpQxgsR" \
#-X GET http://localhost:8888/events/$1
